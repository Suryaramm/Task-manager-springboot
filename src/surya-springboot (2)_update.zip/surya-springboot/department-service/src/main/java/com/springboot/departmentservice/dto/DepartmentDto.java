package com.springboot.departmentservice.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor

public class DepartmentDto {
    private Long id;
    private String department_name;
    private String department_description;
    private String departmentCode;

    public DepartmentDto(Long id, String departmentName, String departmentDescription, String departmentCode) {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDepartment_name() {
        return department_name;
    }

    public void setDepartment_name(String department_name) {
        this.department_name = department_name;
    }

    public String getDepartment_description() {
        return department_description;
    }

    public void setDepartment_description(String department_description) {
        this.department_description = department_description;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        this.departmentCode = departmentCode;
    }

    @Override
    public String toString() {
        return "DepartmentDto{" +
                "id=" + id +
                ", department_name='" + department_name + '\'' +
                ", department_description='" + department_description + '\'' +
                ", departmentCode='" + departmentCode + '\'' +
                '}';
    }
}